function goBackToMain() {
    window.history.go(-1); 
}